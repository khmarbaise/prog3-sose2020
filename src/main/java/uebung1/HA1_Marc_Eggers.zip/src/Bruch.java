import java.math.BigInteger;
import java.util.Comparator;

public class Bruch {
    private int n;
    private int z;

    public Bruch(int z, int n){
        this.z = z;

        // exception werfen falls nenner = 0
        if(n == 0){
            throw new IllegalArgumentException("Nenner darf nicht null sein.");
        }

        this.n = n;
    }

    public int getZ(){
        return z;
    }

    public int getN(){
        return n;
    }

    // setter-methoden sind nicht wirklich sinnvoll - lieber bei Bedarf
    // direkt neuen Bruch erzeugen, ansonsten eventuell Verwirrung

    public String toString(){
        return z + "/" + n;
    }

    // zur besseren Kontrolle der Sortierung nach Wert
    public String toStringPlusDecimal(){
        return z + "/" + n + " (" + this.ausrechnen() + ")";
    }

    /**
     * Multipliziert callenden Bruch mit Bruch b des Arguments.
     * @param b Faktor
     * @return Multiplikationsergebnis als Bruch
     */
    public Bruch multiplizieren(Bruch b){
        return new Bruch(b.getZ() * this.z, b.getN() * this.n);
    }

    /**
     * Berechnet Dezimalwert des Bruchs.
     * @return Dezimalwert des Bruchs
     */
    public double ausrechnen(){
        return (double)this.z/(double)this.n;
    }

    /**
     * Kürzt den callenden Bruch so weit wie möglich.
     */
    public void kuerzen(){
        BigInteger bigZ = BigInteger.valueOf(this.z);
        BigInteger bigN = BigInteger.valueOf(this.n);
        int div = bigZ.gcd(bigN).intValue(); // ggT ermitteln

        this.z = this.z/div;
        this.n = this.n/div;
    }

    /**
     * Bildet den Kehrwert des callenden Bruchs.
     * @return Kehrwert des Bruchs
     */
    public Bruch kehrwert(){
        return new Bruch(this.n, this.z);
    }

    /**
     * Dividiert den callenden Bruch durch Bruch b des Arguments.
     * @param b Divisor
     * @return Divisionsergebnis als Bruch
     */
    public Bruch dividieren(Bruch b){
        return this.multiplizieren(b.kehrwert());
    }
}

/**
 * Comparator-Implementierung für Vergleich der Dezimalwerte von Brüchen
 */
class WertComparator implements Comparator<Bruch> {
    @Override
    public int compare(Bruch a, Bruch b){
        if(a.ausrechnen() < b.ausrechnen()){
            return -1;
        }
        else if(a.ausrechnen() == b.ausrechnen()){
            return 0;
        }
        else{
            return 1;
        }
    }
}

/**
 * Comparator-Implementierung für Vergleich der Zähler von Brüchen
 */
class ZählerComparator implements Comparator<Bruch> {
    @Override
    public int compare(Bruch a, Bruch b){
        if(a.getZ() < b.getZ()){
            return -1;
        }
        else if(a.getZ() == b.getZ()){
            return 0;
        }
        else{
            return 1;
        }
    }
}
