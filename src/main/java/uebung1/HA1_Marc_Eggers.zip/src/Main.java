import java.util.Arrays;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Bruch[] arr = new Bruch[10];
        Random rand = new Random();

        System.out.println("Brüche: ");

        // zufällige Brüche fürs Array erzeugen und ausgeben
        for(int i = 0; i < 10; i++){
            arr[i] = new Bruch(rand.nextInt(101), rand.nextInt(100) + 1);
            System.out.println(arr[i].toString());
        }

        System.out.println();
        System.out.println("Sortiert nach Wert: ");

        // sortieren nach Wert
        Arrays.sort(arr, new WertComparator());
        for (Bruch b : arr){
            System.out.println(b.toStringPlusDecimal());
        }

        System.out.println();
        System.out.println("Sortiert nach Zähler: ");

        // sortieren nach Zähler
        Arrays.sort(arr, new ZählerComparator());
        for (Bruch b : arr){
            System.out.println(b.toString());
        }
    }
}
